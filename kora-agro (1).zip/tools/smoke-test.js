/**
 * End-to-end check with NO internet and NO real Groq key.
 * Starts a fake Groq server and the store against it, then walks through:
 * products -> order -> WhatsApp link -> AI chat tool calls -> validation errors.
 *   npm test
 */
const http = require('http');
const assert = require('assert');
const path = require('path');
const fs = require('fs');

let lastTools = null, lastSystem = '';
const GROQ_PORT = 4101, APP_PORT = 4102;
Object.assign(process.env, {
  GROQ_API_KEY: 'test-key', GROQ_BASE_URL: `http://127.0.0.1:${GROQ_PORT}/openai/v1`, PORT: String(APP_PORT),
  WHATSAPP_NUMBER: '+91 98765 43210', PUBLIC_URL: 'https://shop.example.com', STORE_NAME: 'Kora'
});

/* ---- fake Groq: scripted tool-calling ---- */
const fakeGroq = http.createServer((req, res) => {
  let b = ''; req.on('data', c => b += c); req.on('end', () => {
    const { messages, tools } = JSON.parse(b); if (tools) lastTools = tools; if (/You are Kora/.test(messages[0]?.content || '')) lastSystem = messages[0].content;
    const last = messages[messages.length - 1];
    const call = (name, args) => ({ choices: [{ message: { role: 'assistant', content: '', tool_calls: [{ id: 'c' + Math.random(), type: 'function', function: { name, arguments: JSON.stringify(args) } }] } }] });
    const say = content => ({ choices: [{ message: { role: 'assistant', content } }] });
    const lastUser = [...messages].reverse().find(m => m.role === 'user')?.content || '';
    let out;
    if (/Rewrite this shop assistant reply/.test(last.content || '')) out = say(/Telugu/.test(last.content) ? 'నమస్కారం, ఇది ఫేక్ గ్రోక్ నుండి వచ్చిన తెలుగు సమాధానం.' : /Malayalam/.test(last.content) ? 'നമസ്കാരം, ഇത് ഫേക്ക് ഗ്രോക്കിൽ നിന്നുള്ള മലയാളം മറുപടിയാണ്.' : /Hindi/.test(last.content) ? 'नमस्ते, यह फेक ग्रोक की तरफ़ से हिंदी जवाब है।' : 'Hello, this is an English reply from fake Groq.');
    else if (last.role === 'tool') {
      const t = JSON.parse(last.content);
      out = t.order_id ? say(`Done. Your order ${t.order_id} is placed.`) : t.count ? say(`Showing all ${t.count} products.`) : Array.isArray(t) ? say(`I found ${t.length} options, starting with ${t[0]?.name}.`) : say('Updated your cart.');
    } else if (/headphone/i.test(lastUser)) out = call('search_products', { query: 'tomato seeds', category: null, max_price: null, sort: null });
    else if (/show all seeds/i.test(lastUser)) out = call('show_all_products', { category: 'Seeds', sort: 'price_asc' });
    else if (/show all/i.test(lastUser)) out = call('show_all_products', { category: null, sort: null });
    else if (/add/i.test(lastUser)) out = call('add_to_cart', { product_id: '3', qty: 2 });   // string id on purpose
    else if (/order it/i.test(lastUser)) out = call('place_order', {});                       // uses saved details
    else out = say('Hello from fake Groq.');
    res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(out));
  });
}).listen(GROQ_PORT);

const ordersFile = path.join(__dirname, '..', 'orders.json');
const hadOrders = fs.existsSync(ordersFile) ? fs.readFileSync(ordersFile) : null;
const { handler } = require('../server.js');
const app = http.createServer(handler).listen(APP_PORT);
const base = `http://127.0.0.1:${APP_PORT}`;
const j = async (p, body) => {
  const r = await fetch(base + p, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {});
  return { status: r.status, data: await r.json().catch(() => null) };
};
let n = 0; const ok = m => console.log(`  ✓ ${++n}. ${m}`);

(async () => {
  let r = await j('/api/products');
  assert.equal(r.data.length, 12); assert.ok(r.data.every(p => p.image)); ok('12 products, all with images');
  r = await j('/api/config');
  assert.equal(r.data.whatsapp, '919876543210'); assert.equal(r.data.ai, true); ok('config exposes WhatsApp number and AI flag');

  const html = await (await fetch(base + '/')).text();
  assert.ok(html.includes('https://shop.example.com/img/og.png') && !html.includes('__ORIGIN__')); ok('index.html gets an absolute og:image');
  for (const f of ['/manifest.webmanifest', '/sw.js', '/css/style.css', '/js/app.js', '/icons/icon-512.png', '/icons/maskable-512.png', '/img/products/12.png'])
    assert.equal((await fetch(base + f)).status, 200, f);
  ok('PWA files, css, js, icons and images are served');
  for (const bad of ['/..%2fserver.js', '/%2e%2e/.env', '/..%2f.env']) assert.notEqual((await fetch(base + bad)).status, 200, bad);
  ok('path traversal is blocked');

  /* order + WhatsApp */
  const good = { cart: [{ id: 1, qty: 1 }, { id: 3, qty: 2 }], name: 'Ananya Reddy', phone: '98765 43210', address: '12 Park Street, Banjara Hills, Hyderabad', pincode: '500034', payment: 'upi', notes: 'Call first', location: { lat: 17.4126, lng: 78.4482, accuracy: 18 } };
  r = await j('/api/order', good);
  assert.equal(r.status, 200); const o = r.data;
  assert.deepEqual([o.subtotal, o.delivery, o.total], [13997, 0, 13997]); ok('totals computed on the server, free delivery applied');
  assert.ok(o.whatsapp_url.startsWith('https://wa.me/919876543210?text=')); ok('wa.me link targets the store number');
  const txt = decodeURIComponent(o.whatsapp_url.split('text=')[1]);
  for (const s of [o.id, 'Ananya Reddy', '+91 9876543210', 'maps?q=17.4126,78.4482', 'Aria Wireless Headphones × 1', 'https://shop.example.com/img/products/1.png', '*Total: ₹13,997*', 'UPI', 'Call first'])
    assert.ok(txt.includes(s), 'missing in WhatsApp text: ' + s);
  ok('WhatsApp template has name, phone, address, map pin, items, image links, total, payment, note');
  console.log('\n--------- WhatsApp message ---------\n' + txt + '\n------------------------------------\n');

  r = await j('/api/order', { cart: [{ id: 8, qty: 1 }], name: 'Ravi Kumar', phone: '+91 90000 00001', address: '5 MG Road, Pune' });
  assert.deepEqual([r.data.subtotal, r.data.delivery, r.data.total], [1799, 99, 1898]); assert.ok(!decodeURIComponent(r.data.whatsapp_url).includes('maps?q=')); ok('delivery fee under threshold; no map line without location');

  /* validation + tampering */
  const bads = [
    [{ ...good, phone: '12345' }, /10-digit/], [{ ...good, name: '' }, /name/i], [{ ...good, address: 'x' }, /address/i],
    [{ ...good, pincode: '12' }, /Pincode/], [{ ...good, cart: [] }, /empty/i], [{ ...good, cart: [{ id: 999, qty: 1 }] }, /empty/i]
  ];
  for (const [body, re] of bads) { r = await j('/api/order', body); assert.equal(r.status, 400); assert.match(r.data.error, re); }
  ok('bad phone / name / address / pincode / empty or fake cart all rejected with clear messages');
  r = await j('/api/order', { ...good, cart: [{ id: 1, qty: 9999, price: 1 }] });
  assert.equal(r.data.items[0].qty, 20); assert.equal(r.data.total, 7999 * 20); ok('client-sent prices ignored, quantity capped at 20');

  /* AI chat */
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'show me tomato seeds' }], cart: [] });
  assert.equal(r.status, 200); assert.match(r.data.reply, /found/); assert.ok(r.data.products.includes(1)); ok('chat: search tool runs, product cards returned for the UI');
  const sp = lastTools.find(t => t.function.name === 'search_products').function.parameters;
  assert.ok(sp.properties.category.type.includes('null') && sp.properties.category.enum.includes(null) && sp.properties.max_price.type.includes('null') && sp.properties.sort.type.includes('null'));
  assert.equal(lastTools.find(t => t.function.name === 'get_product').function.parameters.properties.product_id.type, 'integer'); ok('tool schema accepts null for optional fields (fixes Groq validation error), required fields stay strict');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'show all products' }], cart: [] });
  assert.match(r.data.reply, /all 12/); assert.deepEqual(r.data.view, { category: 'All', sort: 'featured' }); assert.equal(r.data.products.length, 12); ok('chat: "show all products" returns a view so the page lists everything and scrolls to it');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'show all seeds, cheapest first' }], cart: [] });
  assert.deepEqual(r.data.view, { category: 'Seeds', sort: 'low' });
  { const all = await j('/api/products'); const pr = r.data.products.map(id => all.data.find(p => p.id === id)); assert.equal(pr.length, 3); assert.ok(pr.every(p => p.category === 'Seeds') && pr[0].price <= pr[1].price && pr[1].price <= pr[2].price); } ok('chat: category + sort are passed to the page');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'do you sell speakers' }], cart: [] });
  assert.ok(r.data.products.length >= 1 && r.data.products.every(id => id === 2) && /found/.test(r.data.reply)); ok('chat: typed product question shows cards even if the AI would not call a tool (plural "speakers" understood)');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'wearables under 6000' }], cart: [] });
  assert.ok(r.data.products.length >= 1); { const all = await j('/api/products'); assert.ok(r.data.products.every(id => { const p = all.data.find(x => x.id === id); return p.category === 'Wearables' && p.price <= 6000; })); } ok('chat: category + price limit in plain text are applied');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'hello' }], cart: [] });
  assert.deepEqual(r.data.products, []); ok('chat: greetings do not trigger product cards');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'add tomato seeds' }], cart: [{ id: 1, qty: 1 }] });
  assert.deepEqual(r.data.cart, [{ id: 1, qty: 1 }, { id: 3, qty: 2 }]); ok('chat: add_to_cart (string id coerced) updates the cart');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'order it' }], cart: [{ id: 3, qty: 1 }], profile: { name: 'Meera', phone: '9123456780', address: '44 Lake View Road, Hyderabad', location: { lat: 17.38, lng: 78.48 } } });
  assert.ok(r.data.order?.id && r.data.order.whatsapp_url.includes('wa.me/919876543210')); assert.deepEqual(r.data.cart, []);
  assert.ok(decodeURIComponent(r.data.order.whatsapp_url).includes('maps?q=17.38,78.48')); ok('chat: place_order uses saved details + location and returns the WhatsApp link');
  /* languages: Kora answers only in the language picked in the app */
  r = await j('/api/config');
  assert.deepEqual(r.data.langs.map(l => l.code), ['en-IN', 'hi-IN', 'te-IN', 'ml-IN']); ok('config lists English, Hindi, Telugu and Malayalam');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'hello' }], cart: [] });
  assert.match(lastSystem, /chose English/); assert.equal(r.data.lang, 'en-IN'); assert.match(r.data.reply, /fake Groq/); ok('chat: default language is English; prompt tells the model to reply in English only');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'hello' }], cart: [], lang: 'xx-XX' });
  assert.equal(r.data.lang, 'en-IN'); ok('chat: unknown language falls back to English');
  for (const [code, name, script, re] of [['te-IN', 'Telugu', 'Telugu', /[\u0C00-\u0C7F]/], ['hi-IN', 'Hindi', 'Devanagari', /[\u0900-\u097F]/], ['ml-IN', 'Malayalam', 'Malayalam', /[\u0D00-\u0D7F]/]]) {
    r = await j('/api/chat', { messages: [{ role: 'user', content: 'hello' }], cart: [], lang: code });
    assert.ok(lastSystem.includes(`chose ${name}`) && lastSystem.includes(script + ' script')); assert.equal(r.data.lang, code);
    assert.match(r.data.reply, re); assert.doesNotMatch(r.data.reply, /fake Groq\.$/);
  }
  ok('chat: Telugu / Hindi / Malayalam rules are sent, and an English slip-up is rewritten in the chosen script');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'order it' }], cart: [], lang: 'te-IN' });
  assert.equal(r.data.order, null); ok('chat: errors in another language still fail safely');
  r = await j('/api/chat', { messages: [{ role: 'user', content: 'order it' }], cart: [] });
  assert.equal(r.data.order, null); ok('chat: placing an order with an empty cart fails safely (tool error, no order)');
})().then(() => console.log(`\nAll ${n} checks passed.`))
  .catch(e => { console.error('\n✗ FAILED:', e.message); process.exitCode = 1; })
  .finally(() => { app.close(); fakeGroq.close(); if (hadOrders) fs.writeFileSync(ordersFile, hadOrders); else try { fs.unlinkSync(ordersFile); } catch {} });
