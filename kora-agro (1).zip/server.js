'use strict';
/**
 * Kora store server — zero dependencies (Node 18+).
 *   - serves /public (PWA, images, css, js)
 *   - /api/products, /api/config, /api/order, /api/chat
 *   - builds the WhatsApp order template (single source of truth for the message)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

/* ---------- .env (tiny loader, replaces dotenv) ---------- */
try {
  for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !line.trim().startsWith('#') && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
} catch { /* no .env — fine */ }

const env = process.env;
const CFG = {
  port: Number(env.PORT) || 3000,
  groqKey: env.GROQ_API_KEY && !/your_groq_key/i.test(env.GROQ_API_KEY) ? env.GROQ_API_KEY : '',
  groqModel: env.GROQ_MODEL || 'openai/gpt-oss-120b',
  groqBase: (env.GROQ_BASE_URL || 'https://api.groq.com/openai/v1').replace(/\/$/, ''),
  whatsapp: (env.WHATSAPP_NUMBER || '').replace(/\D/g, ''),     // e.g. 919876543210
  storeName: env.STORE_NAME || 'Kora',
  publicUrl: (env.PUBLIC_URL || '').replace(/\/$/, ''),
  freeAbove: env.FREE_DELIVERY_ABOVE !== undefined ? Number(env.FREE_DELIVERY_ABOVE) : 1999,
  fee: env.DELIVERY_FEE !== undefined ? Number(env.DELIVERY_FEE) : 99
};

const PUBLIC = path.join(__dirname, 'public');
const products = JSON.parse(fs.readFileSync(path.join(__dirname, 'products.json'), 'utf8'));
const byId = new Map(products.map(p => [p.id, p]));

/* ---------- orders store ---------- */
const FILE = path.join(__dirname, 'orders.json');
let orders = [];
try { orders = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { orders = []; }
function saveOrders() {
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(orders, null, 2));
  fs.renameSync(tmp, FILE);
}

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = msg => new HttpError(400, msg);

/* ---------- helpers ---------- */
const inr = n => '₹' + Number(n).toLocaleString('en-IN');
const clean = (s, max) => String(s ?? '').replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);

function normalizePhone(raw) {
  let d = String(raw ?? '').replace(/\D/g, '');
  if (d.length === 12 && d.startsWith('91')) d = d.slice(2);
  if (d.length === 11 && d.startsWith('0')) d = d.slice(1);
  if (!/^[6-9]\d{9}$/.test(d)) throw bad('Enter a valid 10-digit mobile number.');
  return d;
}

function normalizeCart(cart) {
  if (!Array.isArray(cart)) return [];
  const m = new Map();
  for (const c of cart) {
    const id = Number(c?.id), qty = Math.floor(Number(c?.qty));
    if (!byId.has(id) || !(qty > 0)) continue;
    m.set(id, Math.min(20, (m.get(id) || 0) + qty));
  }
  return [...m].map(([id, qty]) => ({ id, qty }));
}

const lines = cart => cart.map(c => {
  const p = byId.get(c.id);
  return { id: p.id, name: p.name, qty: c.qty, price: p.price, line_total: p.price * c.qty, image: p.image };
});
const subtotal = cart => lines(cart).reduce((s, l) => s + l.line_total, 0);
const deliveryFee = sub => (sub === 0 || sub >= CFG.freeAbove ? 0 : CFG.fee);
const totals = cart => { const s = subtotal(cart), d = deliveryFee(s); return { subtotal: s, delivery: d, total: s + d }; };

function cleanLocation(l) {
  const lat = Number(l?.lat), lng = Number(l?.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  const acc = Number(l?.accuracy);
  return { lat: +lat.toFixed(6), lng: +lng.toFixed(6), accuracy: Number.isFinite(acc) ? Math.round(acc) : null };
}

function newOrderId() {
  for (let i = 0; i < 20; i++) {
    const id = 'KR' + crypto.randomInt(100000, 1000000);
    if (!orders.some(o => o.id === id)) return id;
  }
  return 'KR' + Date.now().toString().slice(-8);
}

function createOrder(cartIn, d) {
  const cart = normalizeCart(cartIn);
  if (!cart.length) throw bad('Your cart is empty.');
  const name = clean(d.name, 80);
  if (name.length < 2) throw bad('Enter your full name.');
  const phone = normalizePhone(d.phone);
  const address = clean(d.address, 400);
  if (address.length < 8) throw bad('Enter a complete delivery address.');
  const pincode = clean(d.pincode, 6);
  if (pincode && !/^\d{6}$/.test(pincode)) throw bad('Pincode must be 6 digits.');
  const payment = d.payment === 'upi' ? 'upi' : 'cod';
  const t = totals(cart);
  const order = {
    id: newOrderId(), name, phone, address, pincode, landmark: clean(d.landmark, 120),
    notes: clean(d.notes, 300), payment, location: cleanLocation(d.location),
    items: lines(cart), subtotal: t.subtotal, delivery: t.delivery, total: t.total,
    status: 'Confirmed', created: new Date().toISOString()
  };
  orders.push(order);
  saveOrders();
  return order;
}

/* ---------- WhatsApp order template ---------- */
function isPublicOrigin(origin) {
  try {
    const h = new URL(origin).hostname;
    return !(h === 'localhost' || /^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h) || /^172\.(1[6-9]|2\d|3[01])\./.test(h) || h.endsWith('.local'));
  } catch { return false; }
}

function whatsappMessage(o, origin) {
  const when = new Date(o.created).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true });
  const withImages = isPublicOrigin(origin);
  const L = [];
  L.push(`🛒 *New order ${o.id}*`, `_${CFG.storeName} · ${when}_`, '');
  L.push(`👤 *Name:* ${o.name}`, `📞 *Phone:* +91 ${o.phone}`);
  L.push(`📍 *Deliver to:* ${o.address}${o.pincode && !o.address.includes(o.pincode) ? ' - ' + o.pincode : ''}`);
  if (o.landmark) L.push(`🏷️ *Landmark:* ${o.landmark}`);
  if (o.location) L.push(`🗺️ *Map pin:* https://www.google.com/maps?q=${o.location.lat},${o.location.lng}`);
  L.push('', '*Items*');
  o.items.forEach((i, n) => {
    L.push(`${n + 1}. ${i.name} × ${i.qty} — ${inr(i.line_total)}`);
    if (withImages && i.image) L.push(`   🖼️ ${origin}${i.image}`);
  });
  L.push('', `Subtotal: ${inr(o.subtotal)}`, `Delivery: ${o.delivery ? inr(o.delivery) : 'FREE'}`, `*Total: ${inr(o.total)}*`);
  L.push(`💳 *Payment:* ${o.payment === 'upi' ? 'UPI / card (please send a pay link)' : 'Cash on delivery'}`);
  if (o.notes) L.push(`📝 *Note:* ${o.notes}`);
  L.push('', 'Please confirm this order. Thank you! 🙏');
  return L.join('\n');
}

function withWhatsApp(o, origin) {
  const text = whatsappMessage(o, origin);
  const url = `https://wa.me/${CFG.whatsapp}?text=${encodeURIComponent(text)}`;
  return { ...o, whatsapp_text: text, whatsapp_url: url, store_whatsapp: CFG.whatsapp };
}

function originOf(req) {
  if (CFG.publicUrl) return CFG.publicUrl;
  const proto = (req.headers['x-forwarded-proto'] || 'http').split(',')[0].trim();
  const host = (req.headers['x-forwarded-host'] || req.headers.host || 'localhost').split(',')[0].trim();
  return `${proto}://${host}`;
}

/* ---------- languages: the customer picks one in the app, Kora answers ONLY in it ---------- */
const LANGS = {
  'en-IN': { name: 'English', script: '', re: null },
  'hi-IN': { name: 'Hindi', script: 'Devanagari', re: /[\u0900-\u097F]/g },
  'te-IN': { name: 'Telugu', script: 'Telugu', re: /[\u0C00-\u0C7F]/g },
  'ml-IN': { name: 'Malayalam', script: 'Malayalam', re: /[\u0D00-\u0D7F]/g }
};
const STUCK = {
  'en-IN': 'Sorry, I got stuck on that. Could you say it again?',
  'hi-IN': 'माफ़ कीजिए, मैं अटक गई। क्या आप फिर से कह सकते हैं?',
  'te-IN': 'క్షమించండి, నాకు అర్థం కాలేదు. మళ్ళీ చెప్పగలరా?',
  'ml-IN': 'ക്ഷമിക്കണം, എനിക്ക് മനസ്സിലായില്ല. ഒന്നുകൂടി പറയാമോ?'
};
const langRule = code => {
  const L = LANGS[code];
  if (!L.script) return 'LANGUAGE RULE (highest priority): the customer chose English in the app. Write every reply in English only, even if the customer writes or speaks another language.';
  return `LANGUAGE RULE (highest priority): the customer chose ${L.name} in the app. Write every reply only in ${L.name}, in ${L.script} script (never in English letters), even if the customer writes or speaks English or another language. Do not mix languages. Product names, brand names and order ids stay exactly as in the catalog. Write numbers as digits and amounts like ₹2,999. Tool arguments always stay in English.`;
};
/* Safety net: if the model still answers in the wrong language, rewrite the reply once. */
function langOK(text, code) {
  const letters = text.match(/\p{L}/gu) || [];
  if (letters.length < 12) return true;
  const L = LANGS[code];
  if (!L.re) return letters.filter(c => !/[A-Za-z\u00C0-\u024F]/.test(c)).length / letters.length < 0.1;
  return (text.match(L.re) || []).length / letters.length > 0.4;
}
async function enforceLang(reply, code) {
  if (!reply || langOK(reply, code)) return reply;
  const L = LANGS[code];
  try {
    const d = await groq([
      { role: 'system', content: 'You rewrite text. Output only the rewritten text and nothing else.' },
      { role: 'user', content: `Rewrite this shop assistant reply entirely in ${L.name}${L.script ? ' using ' + L.script + ' script' : ''}. Keep product names, ₹ amounts, order ids and numbers unchanged. Plain text, no markdown.\n\n${reply}` }
    ], false);
    const t = d.choices?.[0]?.message?.content?.trim();
    return t && langOK(t, code) ? t : reply;
  } catch { return reply; }
}

/* ---------- AI assistant ---------- */
const TOOLS = [
  ['search_products', 'Search the catalog. Use for any product question, browsing or recommendation.', { query: { type: 'string' }, category: { type: 'string', enum: ['Seeds', 'Fertilizers', 'Crop Care', 'Farm Tools'] }, max_price: { type: 'number' }, sort: { type: 'string', enum: ['price_asc', 'price_desc'] } }, []],
  ['show_all_products', 'Show every product (or a whole category) as product cards inside the chat. Use when the customer asks to see all products, the whole catalog, everything, or a full category.', { category: { type: 'string', enum: ['Seeds', 'Fertilizers', 'Crop Care', 'Farm Tools'] }, sort: { type: 'string', enum: ['price_asc', 'price_desc'] } }, []],
  ['get_product', 'Get full details of one product by id.', { product_id: { type: 'integer' } }, ['product_id']],
  ['add_to_cart', 'Add a product to the cart by id.', { product_id: { type: 'integer' }, qty: { type: 'integer' } }, ['product_id']],
  ['update_cart_quantity', 'Set the exact quantity of a product already in the cart. 0 removes it.', { product_id: { type: 'integer' }, qty: { type: 'integer' } }, ['product_id', 'qty']],
  ['remove_from_cart', 'Remove a product from the cart by id.', { product_id: { type: 'integer' } }, ['product_id']],
  ['clear_cart', 'Empty the cart.', {}, []],
  ['show_cart', 'Show the current cart with delivery and total.', {}, []],
  ['place_order', 'Place the order. Only call after the customer gave (or confirmed saved) name, phone and delivery address, heard the total, and clearly said yes.', { name: { type: 'string' }, phone: { type: 'string' }, address: { type: 'string' }, payment: { type: 'string', enum: ['cod', 'upi'] }, notes: { type: 'string' } }, ['name', 'phone', 'address']],
  ['track_order', 'Look up an order by its id.', { order_id: { type: 'string' } }, ['order_id']]
].map(([name, description, properties, required]) => {
  /* Models often send null for optional fields. Allow it in the schema so Groq does not reject the call. */
  const props = {};
  for (const [k, v] of Object.entries(properties)) props[k] = required.includes(k) ? v : { ...v, type: [v.type, 'null'], ...(v.enum ? { enum: [...v.enum, null] } : {}) };
  return { type: 'function', function: { name, description, parameters: { type: 'object', properties: props, required } } };
});

const cartView = st => ({ cart: lines(st.cart).map(({ id, name, qty, price, line_total }) => ({ id, name, qty, price, line_total })), ...totals(st.cart) });

function runTool(name, a, st) {
  a = Object.fromEntries(Object.entries(a || {}).filter(([, v]) => v !== null));
  const pid = Number(a.product_id);
  switch (name) {
    case 'search_products': {
      const words = String(a.query || '').toLowerCase().split(/[^a-z0-9ऀ-෿]+/).filter(w => w.length > 1);
      let r = products.filter(p => (!a.category || p.category === a.category) && (!a.max_price || p.price <= Number(a.max_price)));
      if (words.length) {
        r = r.map(p => {
          const hay = (p.name + ' ' + p.category + ' ' + p.desc + ' ' + p.kw).toLowerCase();
          return { p, s: words.reduce((s, w) => s + (hay.includes(w) ? (p.name.toLowerCase().includes(w) ? 3 : 1) : 0), 0) };
        }).filter(x => x.s > 0).sort((x, y) => y.s - x.s).map(x => x.p);
      }
      if (a.sort === 'price_asc') r = [...r].sort((x, y) => x.price - y.price);
      if (a.sort === 'price_desc') r = [...r].sort((x, y) => y.price - x.price);
      r = r.slice(0, 8);
      r.forEach(p => st.shown.includes(p.id) || st.shown.push(p.id));
      return r.map(({ id, name, category, price, desc }) => ({ id, name, category, price_inr: price, desc }));
    }
    case 'show_all_products': {
      const category = ['Seeds', 'Fertilizers', 'Crop Care', 'Farm Tools'].includes(a.category) ? a.category : 'All';
      const sort = a.sort === 'price_asc' ? 'low' : a.sort === 'price_desc' ? 'high' : 'featured';
      st.view = { category, sort };
      const list = products.filter(p => category === 'All' || p.category === category);
      const ordered = sort === 'low' ? [...list].sort((x, y) => x.price - y.price) : sort === 'high' ? [...list].sort((x, y) => y.price - x.price) : list;
      st.shown = ordered.map(p => p.id);
      return { ok: true, count: list.length, products: list.map(({ id, name, price }) => ({ id, name, price_inr: price })) };
    }
    case 'get_product': {
      const p = byId.get(pid);
      return p ? { id: p.id, name: p.name, category: p.category, price_inr: p.price, desc: p.desc, badge: p.badge || undefined } : { error: 'Product not found' };
    }
    case 'add_to_cart': {
      const p = byId.get(pid);
      if (!p) return { error: 'Product not found' };
      const n = Math.min(20, Math.max(1, Math.floor(Number(a.qty)) || 1));
      const i = st.cart.find(c => c.id === p.id);
      i ? (i.qty = Math.min(20, i.qty + n)) : st.cart.push({ id: p.id, qty: n });
      return { ok: true, ...cartView(st) };
    }
    case 'update_cart_quantity': {
      const i = st.cart.find(c => c.id === pid);
      if (!i) return { error: 'That product is not in the cart' };
      const q = Math.min(20, Math.max(0, Math.floor(Number(a.qty)) || 0));
      st.cart = q ? st.cart.map(c => c.id === pid ? { ...c, qty: q } : c) : st.cart.filter(c => c.id !== pid);
      return { ok: true, ...cartView(st) };
    }
    case 'remove_from_cart':
      st.cart = st.cart.filter(c => c.id !== pid);
      return { ok: true, ...cartView(st) };
    case 'clear_cart': st.cart = []; return { ok: true, ...cartView(st) };
    case 'show_cart': return cartView(st);
    case 'place_order': {
      const pr = st.profile;
      st.order = createOrder(st.cart, {
        name: a.name || pr.name, phone: a.phone || pr.phone, address: a.address || pr.address,
        pincode: pr.pincode, landmark: pr.landmark, notes: a.notes, payment: a.payment,
        location: (!a.address || a.address === pr.address) ? pr.location : null
      });
      st.cart = [];
      return { ok: true, order_id: st.order.id, subtotal: st.order.subtotal, delivery: st.order.delivery, total: st.order.total };
    }
    case 'track_order': {
      const id = String(a.order_id || '').toUpperCase().replace(/\s/g, '');
      const o = orders.find(x => x.id === id);
      return o ? { id: o.id, status: o.status, total: o.total, items: o.items.map(i => i.name + ' x' + i.qty) } : { error: 'Order not found' };
    }
  }
  return { error: 'Unknown tool' };
}

const systemPrompt = (st, code) => {
  const pr = st.profile;
  const saved = pr.name || pr.phone || pr.address
    ? `Saved details on this device: name=${pr.name || 'none'}, phone=${pr.phone || 'none'}, address=${pr.address || 'none'}. Offer to use them instead of asking again.`
    : 'No saved customer details yet.';
  return `You are Kora, the friendly shopping assistant and crop advisor of ${CFG.storeName}, an online agriculture store in India selling seeds, fertilizers, crop-care products and farm tools. When a farmer describes a crop, season, soil or pest problem, give one short practical tip, then search the catalog and recommend matching products. Never promise yields and tell them to check the label or ask a local agriculture officer for serious crop diseases. Prices are in Indian rupees (₹).
Customers type or speak, and replies may be read aloud: use 1-3 short sentences, plain text, no markdown, no lists, no emojis. ${langRule(code)}
Always use tools for product facts, cart changes and orders. Never invent products, prices or order ids. When you search, the app shows product cards, so mention at most three by name with price instead of reading everything.
When the customer asks to see all products, the whole catalog, a full category, or to scroll through everything, call show_all_products (set category or sort only if they asked for it) and tell them the products are shown right here in the chat. Leave optional tool arguments out when you do not need them; never pass null.
Delivery is free above ₹${CFG.freeAbove}, otherwise ₹${CFG.fee}.
When the customer says they want to buy or order a product: confirm which product (search if unsure), add it with add_to_cart, then ask for the missing name, phone and delivery address.
To place an order: you need name, phone number and delivery address. ${saved} Read the cart total (with delivery) back and wait for a clear yes before calling place_order. Ask cash on delivery or UPI only if the customer cares; default is cash on delivery.
After placing it, say the order id slowly and tell the customer to tap the green Send on WhatsApp button to send the order to the store.`;
};

async function groq(messages, useTools = true) {
  for (let attempt = 0; attempt < 3; attempt++) {
    const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 30000);
    try {
      const r = await fetch(CFG.groqBase + '/chat/completions', {
        method: 'POST', signal: ctl.signal,
        headers: { Authorization: 'Bearer ' + CFG.groqKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: CFG.groqModel, messages, ...(useTools ? { tools: TOOLS, tool_choice: 'auto' } : {}), temperature: 0.3, max_tokens: 1500, reasoning_effort: 'low' })
      });
      const d = await r.json().catch(() => ({}));
      if (r.ok) return d;
      const code = d.error?.code || '';
      if ((code === 'tool_use_failed' || r.status === 429 || r.status >= 500) && attempt < 2) { await new Promise(s => setTimeout(s, 400 * (attempt + 1))); continue; }
      throw new HttpError(r.status === 429 ? 429 : 502, r.status === 429 ? 'Kora is busy right now. Try again in a few seconds.' : (d.error?.message || 'AI service error ' + r.status));
    } finally { clearTimeout(timer); }
  }
}

/* Product requests are detected here, so cards always appear even when the AI model answers in plain text and forgets to call a tool. */
const STOP = new Set(('show me see list display browse find search all every everything whole entire full complete catalog catalogue collection range inventory product products item items stuff things please pls plz can could would you your yours i we want need to a an the of in on for my some any what which do does have has sell is are am available give tell about under below above over within upto up rupees rupee rs inr cheap cheapest cheaper lowest highest expensive costly premium best price priced cost sorted sort by first and with from store shop buy get looking look suggest recommend option options more other another new top good nice hi hello hey kora sir bro there here it this that these those also just only like show-me').split(' '));
const CART_WORDS = /\b(add|remove|delete|clear|cart|checkout|check out|place|confirm|cancel|track|order|ordered|deliver|delivery|address|phone|number|payment|pay|cod|upi)\b/;
const TRIGGER = /\b(show|see|list|display|browse|find|search|looking|need|want|suggest|recommend|products?|items?|catalog(ue)?|collection|available|sell|have|under|below|cheap(est)?|gift|best|options?|compare|all|everything)\b/;
const TRIGGER_INDIC = /(दिखा|सभी|सारे|प्रोडक्ट|उत्पाद|सामान|అన్ని|చూపించు|చూపించండి|ప్రొడక్ట్|ప్రోడక్ట్|എല്ലാ|കാണിക്ക|ഉൽപ്പന്ന|പ്രൊഡക്റ്റ്)/;
function preSearch(text, st) {
  const raw = String(text || '').slice(0, 300), t = raw.toLowerCase();
  if (!t.trim() || CART_WORDS.test(t)) return null;
  const trigger = TRIGGER.test(t) || TRIGGER_INDIC.test(raw);
  const m = t.match(/(?:under|below|less than|within|upto|up to|max|maximum|budget|₹|rs\.?|inr)\s*(\d[\d,]*)/);
  const max = m ? Number(m[1].replace(/,/g, '')) : null;
  const sort = /\b(cheap(est)?|lowest|low to high|affordable)\b/.test(t) ? 'price_asc' : /\b(expensive|premium|highest|high to low|costly)\b/.test(t) ? 'price_desc' : null;
  const stem = w => w.replace(/(ches|shes|xes)$/, x => x.slice(0, -2)).replace(/(?<=[a-z]{3})s$/, '');
  let words = t.split(/[^a-z0-9ऀ-෿]+/).filter(w => w.length > 1 && !/^\d+$/.test(w) && !STOP.has(w)).map(stem);
  const cats = [...new Set(products.map(p => p.category))];
  const category = cats.find(c => words.some(w => w.length >= 4 && w.startsWith(c.toLowerCase().slice(0, 6))));
  if (category) words = words.filter(w => !(w.length >= 4 && w.startsWith(category.toLowerCase().slice(0, 6))));
  let name, args;
  if (!words.length) {
    if (!trigger && !category) return null;
    if (category && !max) { name = 'show_all_products'; args = { category, sort }; }
    else if (max) { name = 'search_products'; args = { query: category || '', max_price: max, sort }; }
    else { name = 'show_all_products'; args = { sort }; }
  } else { name = 'search_products'; args = { query: [category, ...words].filter(Boolean).join(' '), max_price: max, sort }; }
  const out = runTool(name, args, st);
  if (Array.isArray(out) && !out.length) return null;
  const clean = Object.fromEntries(Object.entries(args).filter(([, v]) => v !== null && v !== ''));
  const id = 'pre_' + Date.now().toString(36);
  return [{ role: 'assistant', content: '', tool_calls: [{ id, type: 'function', function: { name, arguments: JSON.stringify(clean) } }] }, { role: 'tool', tool_call_id: id, content: JSON.stringify(out) }];
}

async function chat(body, origin) {
  if (!CFG.groqKey) throw new HttpError(503, 'The AI assistant is not set up yet. Add GROQ_API_KEY to the .env file.');
  const code = LANGS[body.lang] ? body.lang : 'en-IN';
  const pr = body.profile || {};
  const st = {
    cart: normalizeCart(body.cart), order: null, shown: [], view: null,
    profile: { name: clean(pr.name, 80), phone: clean(pr.phone, 20), address: clean(pr.address, 400), pincode: clean(pr.pincode, 6), landmark: clean(pr.landmark, 120), location: cleanLocation(pr.location) }
  };
  const history = (Array.isArray(body.messages) ? body.messages : []).slice(-14)
    .filter(m => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .map(m => ({ role: m.role, content: m.content.slice(0, 1000) }));
  const msgs = [{ role: 'system', content: systemPrompt(st, code) }, ...history];
  const lastUser = history.length && history[history.length - 1].role === 'user' ? history[history.length - 1].content : '';
  const pre = preSearch(lastUser, st);
  if (pre) msgs.push(...pre);
  for (let i = 0; i < 6; i++) {
    const d = await groq(msgs);
    const m = d.choices?.[0]?.message;
    if (!m) throw new HttpError(502, 'Empty reply from AI service');
    if (!m.tool_calls?.length) {
      return { reply: await enforceLang(m.content || '', code), cart: st.cart, order: st.order ? withWhatsApp(st.order, origin) : null, products: st.shown, view: st.view, lang: code };
    }
    msgs.push({ role: 'assistant', content: m.content || '', tool_calls: m.tool_calls });
    for (const t of m.tool_calls) {
      let out;
      try { out = runTool(t.function.name, JSON.parse(t.function.arguments || '{}'), st); }
      catch (e) { out = { error: e.message }; }
      msgs.push({ role: 'tool', tool_call_id: t.id, content: JSON.stringify(out) });
    }
  }
  return { reply: STUCK[code], cart: st.cart, order: st.order ? withWhatsApp(st.order, origin) : null, products: st.shown, view: st.view, lang: code };
}

/* ---------- tiny http layer ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.woff2': 'font/woff2' };
const COMPRESS = new Set(['.html', '.css', '.js', '.json', '.webmanifest', '.svg']);
const gzCache = new Map();

function send(res, status, body, headers = {}) {
  const isObj = body !== null && typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(status, { 'Content-Type': isObj ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(isObj ? JSON.stringify(body) : body);
}

function readJson(req, limit = 100 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(new HttpError(413, 'Request too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { reject(bad('Invalid JSON')); } });
    req.on('error', reject);
  });
}

const hits = new Map();
function limited(ip, max, windowMs = 60000) {
  const now = Date.now(), h = (hits.get(ip) || []).filter(t => now - t < windowMs);
  h.push(now); hits.set(ip, h);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || now - v[v.length - 1] > windowMs) hits.delete(k);
  return h.length > max;
}

function serveStatic(req, res, pathname) {
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { return send(res, 400, 'Bad request'); }
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.normalize(path.join(PUBLIC, rel));
  if (file !== PUBLIC && !file.startsWith(PUBLIC + path.sep)) return send(res, 403, 'Forbidden');
  if (file === path.join(PUBLIC, 'index.html')) {          // fill in the absolute address for link previews
    return fs.readFile(file, 'utf8', (err, html) => {
      if (err) return send(res, 404, 'Not found');
      send(res, 200, html.replace(/__ORIGIN__/g, originOf(req)), { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-cache' });
    });
  }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(res, 404, 'Not found');
    const ext = path.extname(file).toLowerCase();
    const noCache = ext === '.html' || rel === '/sw.js' || ext === '.webmanifest';
    const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': noCache ? 'no-cache' : 'public, max-age=3600', 'Last-Modified': st.mtime.toUTCString(), 'X-Content-Type-Options': 'nosniff' };
    if (rel === '/sw.js') headers['Service-Worker-Allowed'] = '/';
    if (req.headers['if-modified-since'] && new Date(req.headers['if-modified-since']) >= new Date(Math.floor(st.mtimeMs / 1000) * 1000)) { res.writeHead(304, headers); return res.end(); }
    const gz = COMPRESS.has(ext) && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
    if (!gz) { res.writeHead(200, { ...headers, 'Content-Length': st.size }); return req.method === 'HEAD' ? res.end() : fs.createReadStream(file).pipe(res); }
    const key = file + st.mtimeMs;
    const done = buf => { res.writeHead(200, { ...headers, 'Content-Encoding': 'gzip', 'Content-Length': buf.length, Vary: 'Accept-Encoding' }); res.end(req.method === 'HEAD' ? undefined : buf); };
    if (gzCache.has(key)) return done(gzCache.get(key));
    fs.readFile(file, (e, data) => { if (e) return send(res, 500, 'Read error'); const z = zlib.gzipSync(data); gzCache.set(key, z); done(z); });
  });
}

async function handler(req, res) {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(self), microphone=(self), camera=()');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  if ((req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https') res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self' https://nominatim.openstreetmap.org https://fonts.googleapis.com https://fonts.gstatic.com; manifest-src 'self'; worker-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
  try {
    if (p.startsWith('/api/')) {
      const ip = req.socket.remoteAddress || '';
      if (req.method === 'GET' && p === '/api/products') return send(res, 200, products, { 'Cache-Control': 'no-cache' });
      if (req.method === 'GET' && p === '/api/config') return send(res, 200, { storeName: CFG.storeName, whatsapp: CFG.whatsapp, freeAbove: CFG.freeAbove, fee: CFG.fee, ai: !!CFG.groqKey, langs: Object.entries(LANGS).map(([code, l]) => ({ code, name: l.name })) });
      if (req.method === 'GET' && p.startsWith('/api/order/')) {
        const o = orders.find(x => x.id === decodeURIComponent(p.slice(11)).toUpperCase());
        return o ? send(res, 200, { id: o.id, status: o.status, total: o.total, created: o.created }) : send(res, 404, { error: 'Order not found' });
      }
      if (req.method === 'POST' && p === '/api/order') {
        if (limited(ip + 'o', 10)) throw new HttpError(429, 'Too many orders. Please wait a minute.');
        const b = await readJson(req);
        return send(res, 200, withWhatsApp(createOrder(b.cart, b), originOf(req)));
      }
      if (req.method === 'POST' && p === '/api/chat') {
        if (limited(ip + 'c', 40)) throw new HttpError(429, 'Slow down a little. Try again in a moment.');
        return send(res, 200, await chat(await readJson(req), originOf(req)));
      }
      return send(res, 404, { error: 'Not found' });
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed');
    return serveStatic(req, res, p);
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error(e);
    send(res, status, { error: status === 500 ? 'Something went wrong on our side.' : e.message });
  }
}

if (require.main === module) {
  http.createServer(handler).listen(CFG.port, () => {
    console.log(`Kora store running at http://localhost:${CFG.port}`);
    console.log(`  AI assistant : ${CFG.groqKey ? 'ready (' + CFG.groqModel + ')' : 'OFF — set GROQ_API_KEY in .env'}`);
    console.log(`  WhatsApp     : ${CFG.whatsapp ? '+' + CFG.whatsapp : 'no WHATSAPP_NUMBER set — customers will pick a chat manually'}`);
  });
}
module.exports = { handler, createOrder, whatsappMessage };
