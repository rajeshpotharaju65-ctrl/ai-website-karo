/* Kora service worker: makes the store installable and lets it open offline. */
const VERSION = 'kora-agro-v4.0';
const SHELL = [
  '/', '/css/style.css', '/css/pro.css', '/js/app.js', '/js/pro.js', '/manifest.webmanifest',
  '/icons/icon.svg', '/icons/icon-192.png', '/api/products', '/api/config',
  ...Array.from({ length: 12 }, (_, i) => `/img/products/${i + 1}.svg`)
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => Promise.allSettled(SHELL.map(u => c.add(u)))).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

const put = (req, res) => { if (res && (res.ok || res.type === 'opaque')) caches.open(VERSION).then(c => c.put(req, res.clone())); return res; };

self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET') return;                       // never touch orders or chat

  // Google Fonts: cache after first load
  if (/fonts\.(googleapis|gstatic)\.com$/.test(url.hostname)) {
    e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(r => put(req, r))));
    return;
  }
  if (url.origin !== location.origin) return;            // maps, geocoding etc. go straight to the network

  // Live data: network first, last known copy when offline
  if (url.pathname === '/api/products' || url.pathname === '/api/config') {
    e.respondWith(fetch(req).then(r => put(req, r)).catch(() => caches.match(req)));
    return;
  }
  if (url.pathname.startsWith('/api/')) return;

  // Pages: network first so updates show up, cached shell when offline
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).then(r => { put('/', r.clone()); return r; }).catch(() => caches.match('/')));
    return;
  }

  // Everything else (css, js, images, icons): serve cached, refresh in background
  e.respondWith(caches.match(req).then(hit => {
    const net = fetch(req).then(r => put(req, r)).catch(() => hit);
    return hit || net;
  }));
});
